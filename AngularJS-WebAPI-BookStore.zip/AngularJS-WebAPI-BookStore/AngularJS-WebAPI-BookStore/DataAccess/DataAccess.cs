﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;

using Shared;
using Shared.Models;

namespace DataAccess
{
    public class DataManager
    {
        private String connectionString = ConfigurationManager.ConnectionStrings["BookData"].ToString();

        #region Sql Methods

        /// <summary>
        /// Returns a new sql parameter with the given paramenters.
        /// </summary>
        /// <param name="parameterName"></param>
        /// <param name="value"></param>
        /// <param name="dbtype"></param>
        /// <returns></returns>
        private SqlParameter GetParameter(String parameterName, Object value, DbType dbtype)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = parameterName;
            param.Value = value;
            param.DbType = dbtype;
            return param;
        }

        /// <summary>
        /// Returns the connection string.
        /// </summary>
        /// <returns></returns>
        private String GetConnectionString()
        {
            return connectionString;
        }

        /// <summary>
        /// Returns a new sql connection.
        /// </summary>
        /// <returns></returns>
        private SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection(GetConnectionString());
            connection.Open();
            return connection;
        }

        /// <summary>
        /// Closes the provided sql connection.
        /// </summary>
        /// <param name="connection"></param>
        private void CloseConnection(SqlConnection connection)
        {
            connection.Close();
        }

        /// <summary>
        /// Returns the SqlCommand object based on the type of operation passed
        /// </summary>
        /// <param name="operationType"></param>
        /// <returns></returns>
        private SqlCommand GetCommand(String operationType)
        {
            String dataQuery = OperationType.Map[operationType];
            SqlConnection connection = GetConnection();
            SqlCommand command = new SqlCommand(dataQuery, connection);

            return command;
        }

        #endregion Sql Methods

        #region CRUD

        /// <summary>
        /// Get book data for a particular catagory
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public List<BookModel> ReadBookByCategory(Dictionary<String, Object> data)
        {
            BookModel bookModel;
            SqlDataReader dataReader;
            List<BookModel> returnData = new List<BookModel>();
            SqlCommand command = GetCommand(OperationType.ReadByCategory);
            String bookCategory = data["BookCategory"].ToString().ToUpper();

            command.Parameters.Add(GetParameter("@bookCategory", bookCategory, DbType.String));
            dataReader = command.ExecuteReader();
            while (dataReader.Read())
            {
                bookModel = GetBookModel((Int32)dataReader["BookId"],
                                dataReader["BookName"].ToString(),
                                dataReader["AuthorName"].ToString(),
                                dataReader["Edition"].ToString(),
                                (Decimal)dataReader["Price"],
                                (Int32)dataReader["Rating"],
                                dataReader["BookCategory"].ToString(),
                                dataReader["Image"].ToString());

                returnData.Add(bookModel);
            }
            CloseConnection(command.Connection);
            return returnData;
        }

        /// <summary>
        /// Read book by its Id
        /// </summary>
        /// <param name="operationType"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public List<BookModel> ReadBookById(Dictionary<String, Object> data)
        {
            BookModel bookModel;
            SqlDataReader dataReader;
            List<BookModel> returnData = new List<BookModel>();
            SqlCommand command = GetCommand(OperationType.ReadById);
            Int32 bookId = Convert.ToInt32(data["BookId"]);

            command.Parameters.Add(GetParameter("@bookId", bookId, DbType.Int32));
            dataReader = command.ExecuteReader();
            while (dataReader.Read())
            {
                bookModel = GetBookModel((Int32)dataReader["BookId"],
                                dataReader["BookName"].ToString(),
                                dataReader["AuthorName"].ToString(),
                                dataReader["Edition"].ToString(),
                                (Decimal)dataReader["Price"],
                                (Int32)dataReader["Rating"],
                                dataReader["BookCategory"].ToString(),
                                dataReader["Image"].ToString());

                returnData.Add(bookModel);
            }
            CloseConnection(command.Connection);
            return returnData;
        }

        /// <summary>
        /// Read Books Data
        /// </summary>
        /// <returns></returns>
        public List<BookModel> ReadBooksData()
        {
            BookModel bookModel;
            List<BookModel> returnData = new List<BookModel>();
            SqlDataReader dataReader;
            SqlCommand command = GetCommand(OperationType.Read);
            
            
            dataReader = command.ExecuteReader();
            if (dataReader.HasRows)
            {
                while (dataReader.Read())
                {
                    bookModel = GetBookModel((Int32)dataReader["BookId"],
                                    dataReader["BookName"].ToString(),
                                    dataReader["AuthorName"].ToString(),
                                    dataReader["Edition"].ToString(),
                                    (Decimal)dataReader["Price"],
                                    (Int32)dataReader["Rating"],
                                    dataReader["BookCategory"].ToString(),
                                    dataReader["Image"].ToString());
                    returnData.Add(bookModel);
                }
            }
            CloseConnection(command.Connection);
            return returnData;
        }

        #endregion CRUD

        #region Helper Methods

        /// <summary>
        /// Returns new BookModel object with the passed parameters
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="authorName"></param>
        /// <param name="Edition"></param>
        /// <param name="price"></param>
        /// <param name="rating"></param>
        /// <param name="BookCategory"></param>
        /// <param name="image"></param>
        /// <returns></returns>
        private BookModel GetBookModel(Int32 bookId, String bookName, String authorName, String Edition, Decimal price,
                                         Int32 rating,   String bookCategory, String image)
        {
            return new BookModel
            {
                BookId = bookId,
                BookName = bookName,
                AuthorName = authorName,
                Edition = Edition,
                Price = price,                
                Rating = rating,

                BookCategory = bookCategory,
                Image = image
            };
        }

        #endregion Helper Methods
    }
}
