﻿;function MainCtrl($scope, $http, $templateCache) {
    $scope.books = [];
    var tooltipJS = new ToolTipJS();
    //Set the tooltip html content
    var tooltipContent = "<div style='text-align:center'><table>"
    tooltipContent += "<span style='font:bold;font-family:Arial;font-weight:800;font-size:large'>{{BookName}}</span><br />";
    tooltipContent += "<tr><td>Author</td><td>{{AuthorName}}</td></tr>";
    tooltipContent += "<tr><td>Edition</td><td>{{Edition}}</td></tr>";
    tooltipContent += "<tr><td>Price</td><td>{{Price}}</td></tr>";
    
    //set the tooltip location preference, these can be reordered as required
    tooltipJS.addLocationPreference(new tooltipJS.tooltipLocation(tooltipJS.LocationConstants.Top, "tooltip-Css"));
    tooltipJS.addLocationPreference(new tooltipJS.tooltipLocation(tooltipJS.LocationConstants.Right, "tooltip-Css"));
    tooltipJS.addLocationPreference(new tooltipJS.tooltipLocation(tooltipJS.LocationConstants.Left, "tooltip-Css"));
    tooltipJS.addLocationPreference(new tooltipJS.tooltipLocation(tooltipJS.LocationConstants.Bottom, "tooltip-Css"));

    //first lets get all the books
    $http({
        method: 'GET',
        url: 'api/book/',
        cache: $templateCache
    }).
    success(function (data, status, headers, config) {
        $scope.books = data;
    }).
    error(function (data, status) {
        console.log("Request Failed");
    });

    $scope.DivVisibilitySet = function () {
        $("#id1").click(function () {
            $(".divBody").hide();
            $(".divHome").show();
        }); 
    }
    //Get Books by their category
    $scope.GetBooksByCategory = function (bookCategory) {
        $http({
            method: 'POST',
            url: 'api/book/',
            data: JSON.stringify(bookCategory),
            headers: { 'Content-Type': 'application/json; charset=utf-8', 'dataType': 'json' },
            cache: $templateCache
        }).
        success(function (data, status, headers, config) {
            $scope.books = data;
        }).
        error(function (data, status) {
            console.log("Request Failed");
        });
    };
    

    //set the tooltips for all the book images
    $scope.SetToolTip = function (bookId, bookName, author, edition, price,   year) {
        var content = tooltipContent;
        content = content.replace("{{BookName}}", bookName);
        content = content.replace("{{AuthorName}}", author);
        content = content.replace("{{Edition}}", edition);
        content = content.replace("{{Price}}", price);

        tooltipJS.applyTooltip("imgBook" + bookId, content, 5, true);
    };

    //Get our helper methods
    $scope.GetRatingImage = GetRatingImage;
    $scope.GetActualPrice = GetActualPrice;
    $scope.HasDiscount = HasDiscount;
}

function BookCtrl($scope, $http, $templateCache, $routeParams) {
    $scope.bookId = $routeParams.bookId;
    $scope.book = {};

    $http({
        method: 'GET',
        url: 'api/book/' + $scope.bookId,
        cache: $templateCache
    }).
    success(function (data, status, headers, config) {
        $scope.book = data[0];
    }).
    error(function (data, status) {
        console.log("Request Failed");
    });

    //Get our helper methods
    $scope.GetRatingImage = GetRatingImage;
    $scope.GetActualPrice = GetActualPrice;
    $scope.HasDiscount = HasDiscount;
}

//Gets rating image based on the rating value passed
function GetRatingImage(rating) {
    switch (rating) {
        case 0:
            return "0star.png";
            break;
        case 1:
            return "1star.png";
            break;
        case 2:
            return "2star.png";
            break;
        case 3:
            return "3star.png";
            break;
        case 4:
            return "4star.png";
            break;
        case 5:
            return "5star.png";
            break;
    }
}

//Gets the actual price after deducting the discount
function GetActualPrice(price, discount) {
    var discountString = Math.round(discount * 100) + "%";
    var finalPrice = price - (price * discount)
    if (discount > 0) {
        return "Rs. " + Math.round(finalPrice) + "(" + discountString + ")";
    }
    else {
        return "";
    }
};

//Determines if there is any discount for the book or not
function HasDiscount(discount) {
    return (discount > 0);
};