﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Models
{
    public class BookModel
    {
        public Int32 BookId { get; set; }
        public String BookCategory { get; set; }
        public String BookName { get; set; }
        public String AuthorName { get; set; }
        public String Edition { get; set; }
        public Decimal Price { get; set; }
        public Int32 Rating { get; set; }
        
        public String Image { get; set; }
    }
}
